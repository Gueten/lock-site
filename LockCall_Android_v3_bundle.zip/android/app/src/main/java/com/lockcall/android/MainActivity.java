package com.lockcall.android;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements ScreenCaptureService.FrameListener {
    private static final int REQUEST_SCREEN_CAPTURE = 7101;
    private static final int REQUEST_WEB_PERMISSIONS = 7102;
    private static final String SITE_URL = "https://gueten.github.io/lock-site/";

    private WebView webView;
    private PermissionRequest pendingWebPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF111216);
        getWindow().setNavigationBarColor(0xFF111216);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF111216);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new ScreenCaptureBridge(this), "LockScreenBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("gueten.github.io".equalsIgnoreCase(uri.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (pendingWebPermission == request) pendingWebPermission = null;
            }
        });

        setContentView(webView);
        ScreenCaptureService.setFrameListener(this);
        webView.loadUrl(SITE_URL);
        requestNotificationPermissionIfNeeded();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7103);
        }
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        List<String> missing = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.CAMERA);
            }
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            pendingWebPermission = request;
            requestPermissions(missing.toArray(new String[0]), REQUEST_WEB_PERMISSIONS);
        }
    }

    void requestNativeScreenCapture() {
        runOnUiThread(() -> {
            try {
                MediaProjectionManager manager =
                        (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
            } catch (Exception error) {
                sendJavascriptCallback("__lockAndroidCaptureFailed", "Não foi possível abrir a permissão de captura do Android.");
            }
        });
    }

    void stopNativeScreenCapture() {
        try {
            stopService(new Intent(this, ScreenCaptureService.class));
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SCREEN_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            sendJavascriptCallback("__lockAndroidCaptureFailed", "Você cancelou a permissão de compartilhar a tela.");
            return;
        }

        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
        } catch (Exception error) {
            sendJavascriptCallback("__lockAndroidCaptureFailed", "O Android não conseguiu iniciar o serviço de captura. Tente novamente.");
        }
    }

    @Override
    public void onFrame(byte[] jpeg, int width, int height) {
        if (webView == null || jpeg == null || jpeg.length == 0) return;
        String base64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP);
        String js = "window.__lockAndroidCaptureFrame && window.__lockAndroidCaptureFrame(" +
                JSONObject.quote(base64) + "," + width + "," + height + ");";
        webView.post(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    @Override
    public void onCaptureStarted() {
        sendJavascriptCallback("__lockAndroidCaptureStarted", null);
    }

    @Override
    public void onCaptureFailed(String reason) {
        sendJavascriptCallback("__lockAndroidCaptureFailed", reason);
    }

    @Override
    public void onCaptureStopped() {
        sendJavascriptCallback("__lockAndroidCaptureStopped", null);
    }

    private void sendJavascriptCallback(String function, String message) {
        if (webView == null) return;
        String call = "window." + function + " && window." + function + "(" +
                (message == null ? "" : JSONObject.quote(message)) + ");";
        webView.post(() -> {
            if (webView != null) webView.evaluateJavascript(call, null);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WEB_PERMISSIONS && pendingWebPermission != null) {
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            PermissionRequest request = pendingWebPermission;
            pendingWebPermission = null;
            if (granted) request.grant(request.getResources());
            else request.deny();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        ScreenCaptureService.setFrameListener(null);
        if (isFinishing()) stopNativeScreenCapture();
        if (webView != null) {
            webView.removeJavascriptInterface("LockScreenBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static final class ScreenCaptureBridge {
        private final MainActivity activity;

        ScreenCaptureBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void startCapture() {
            activity.requestNativeScreenCapture();
        }

        @JavascriptInterface
        public void stopCapture() {
            activity.stopNativeScreenCapture();
        }
    }
}
