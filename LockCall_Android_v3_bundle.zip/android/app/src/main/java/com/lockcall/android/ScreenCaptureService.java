package com.lockcall.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class ScreenCaptureService extends Service {
    private static final String TAG = "LockCallCapture";
    public static final String ACTION_START = "com.lockcall.android.START_CAPTURE";
    public static final String ACTION_STOP = "com.lockcall.android.STOP_CAPTURE";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";

    private static final String CHANNEL_ID = "lockcall_screen_capture";
    private static final int NOTIFICATION_ID = 7104;
    private static final int MAX_LONG_EDGE = 720;
    private static final long FRAME_INTERVAL_MS = 100L;

    public interface FrameListener {
        void onFrame(byte[] jpeg, int width, int height);
        void onCaptureStarted();
        void onCaptureFailed(String reason);
        void onCaptureStopped();
    }

    private static volatile FrameListener frameListener;
    public static void setFrameListener(FrameListener listener) {
        frameListener = listener;
    }

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private long lastFrameAt;
    private boolean stopping;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopCapture(true);
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY;

        try {
            startAsForeground();
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData = getResultData(intent);
            if (resultData == null) throw new IllegalStateException("Dados da permissão de captura ausentes.");

            MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("O Android não iniciou a captura de tela.");

            DisplayMetrics metrics = getScreenMetrics();
            int width = Math.max(2, metrics.widthPixels);
            int height = Math.max(2, metrics.heightPixels);
            int density = Math.max(1, metrics.densityDpi);

            captureThread = new HandlerThread("LockCallFrameCapture");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);

            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopCapture(true);
                }
            }, new Handler(getMainLooper()));

            virtualDisplay = projection.createVirtualDisplay(
                    "LockCall Screen",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    captureHandler
            );
            if (virtualDisplay == null) throw new IllegalStateException("Não foi possível criar a tela virtual.");

            FrameListener listener = frameListener;
            if (listener != null) listener.onCaptureStarted();
        } catch (Exception error) {
            Log.e(TAG, "Falha ao iniciar captura", error);
            FrameListener listener = frameListener;
            if (listener != null) listener.onCaptureFailed(
                    error.getMessage() == null ? "Falha ao iniciar a captura de tela." : error.getMessage());
            stopCapture(false);
        }
        return START_NOT_STICKY;
    }

    private Intent getResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) {
            return intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        }
        //noinspection deprecation
        return intent.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private DisplayMetrics getScreenMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (windowManager != null) {
            Display display = windowManager.getDefaultDisplay();
            //noinspection deprecation
            display.getRealMetrics(metrics);
        } else {
            metrics.setTo(getResources().getDisplayMetrics());
        }
        return metrics;
    }

    private void startAsForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, ScreenCaptureService.class).setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPending = PendingIntent.getService(this, 7105, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return builder
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("LockCall está transmitindo sua tela")
                .setContentText("Toque em Parar para encerrar o compartilhamento.")
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Parar", stopPending)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Compartilhamento de tela", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Notificação exibida enquanto o LockCall captura a tela.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastFrameAt < FRAME_INTERVAL_MS) return;
            lastFrameAt = now;

            Image.Plane[] planes = image.getPlanes();
            if (planes.length == 0) return;
            Image.Plane plane = planes[0];
            ByteBuffer buffer = plane.getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = Math.max(0, rowStride - pixelStride * width);
            int paddedWidth = width + rowPadding / Math.max(1, pixelStride);

            Bitmap padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind();
            padded.copyPixelsFromBuffer(buffer);
            Bitmap cropped = paddedWidth == width ? padded : Bitmap.createBitmap(padded, 0, 0, width, height);
            if (cropped != padded) padded.recycle();

            float scale = Math.min(1f, (float) MAX_LONG_EDGE / Math.max(width, height));
            int outWidth = Math.max(2, Math.round(width * scale));
            int outHeight = Math.max(2, Math.round(height * scale));
            Bitmap output = (outWidth == width && outHeight == height)
                    ? cropped
                    : Bitmap.createScaledBitmap(cropped, outWidth, outHeight, true);
            if (output != cropped) cropped.recycle();

            ByteArrayOutputStream bytes = new ByteArrayOutputStream(64 * 1024);
            output.compress(Bitmap.CompressFormat.JPEG, 55, bytes);
            if (output != cropped) output.recycle();
            else cropped.recycle();

            FrameListener listener = frameListener;
            if (listener != null && bytes.size() > 0) listener.onFrame(bytes.toByteArray(), outWidth, outHeight);
        } catch (Exception error) {
            Log.w(TAG, "Falha ao converter quadro da tela", error);
        } finally {
            if (image != null) image.close();
        }
    }

    private void stopCapture(boolean notifyPage) {
        if (stopping) return;
        stopping = true;
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.setOnImageAvailableListener(null, null);
                imageReader.close();
                imageReader = null;
            }
            if (projection != null) {
                MediaProjection current = projection;
                projection = null;
                try { current.stop(); } catch (Exception ignored) {}
            }
            if (captureThread != null) {
                captureThread.quitSafely();
                captureThread = null;
                captureHandler = null;
            }
        } catch (Exception error) {
            Log.w(TAG, "Erro ao finalizar captura", error);
        }
        if (notifyPage) {
            FrameListener listener = frameListener;
            if (listener != null) listener.onCaptureStopped();
        }
        try {
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
            else {
                //noinspection deprecation
                stopForeground(true);
            }
        } catch (Exception ignored) {
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopping) stopCapture(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
