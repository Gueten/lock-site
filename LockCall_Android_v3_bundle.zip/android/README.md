# LockCall Android companion

Abra esta pasta no Android Studio. O aplicativo é um WebView seguro que carrega o GitHub Pages do LockCall e disponibiliza uma ponte Java para MediaProjection.

O aplicativo não substitui o site nem altera o protocolo de sala: a captura Android é convertida em um MediaStream de canvas no JavaScript e enviada pelo fluxo PeerJS existente.

Consulte `../README.md` para publicação, build e limitações.
