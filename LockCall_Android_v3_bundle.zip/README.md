# LockCall Android v3

Este pacote adiciona um aplicativo Android complementar ao LockCall v3.0 para permitir o compartilhamento de tela em aparelhos Android que não expõem `getDisplayMedia()` ao navegador.

## O que foi alterado

- `index.html` (e a cópia em `site/index.html`): versão do site com suporte ao bridge nativo Android. No PC, continua usando `getDisplayMedia()` e o fluxo PeerJS/WebRTC já existente.
- `android/`: projeto Android Studio em Java. Usa a permissão oficial `MediaProjection`, captura a tela no serviço em primeiro plano e encaminha quadros JPEG para um canvas do site. O canvas produz um `MediaStream` que entra no mesmo fluxo de transmissão do LockCall.
- `.github/workflows/android-debug-apk.yml`: compila um APK de teste no GitHub Actions quando os arquivos Android são enviados ao repositório.

## Importante: como usar no Motorola G32

O site publicado no GitHub Pages continua sendo usado para assistir às salas pelo Chrome. Para **transmitir a tela do próprio G32**, abra o LockCall pelo aplicativo Android construído a partir da pasta `android/`.

1. Extraia este pacote e copie o `index.html` da raiz para a raiz do repositório GitHub Pages, substituindo o arquivo antigo.
2. Copie as pastas `android/` e `.github/workflows/` deste pacote para a raiz do mesmo repositório GitHub Pages e envie um commit. A estrutura no GitHub deve ficar com `index.html`, `android/` e `.github/workflows/android-debug-apk.yml` no primeiro nível.
3. No GitHub, abra a aba **Actions**. O workflow **Build LockCall Android APK** compilará um APK de teste automaticamente. Também é possível iniciar o workflow manualmente.
4. Abra a execução concluída e baixe o artefato `LockCall-Android-debug-apk`. Extraia `app-debug.apk` e instale-o no Motorola G32. Talvez seja necessário autorizar a instalação pelo aplicativo usado para abrir o APK.
5. Abra **LockCall Android**, entre/crie a sala e toque em **Compartilhar tela**.
6. Confirme a janela de captura do Android. Depois, pressione Home e abra o aplicativo ou tela que deseja mostrar. A notificação persistente do LockCall indica que a captura está ativa.
7. Para encerrar, volte ao LockCall e toque em **Parar transmissão**, ou use **Parar** na notificação do Android.

## Limitações desta implementação Android

- O modo Android encaminha vídeo da tela em até aproximadamente 10 quadros por segundo e reduz a imagem para no máximo 720 pixels no lado maior. Isso evita sobrecarregar o Motorola G32, mas não tem a mesma fluidez do compartilhamento no PC.
- O áudio interno do Android não é capturado neste modo. O microfone do LockCall continua sendo um recurso separado.
- O app usa a página pública `https://gueten.github.io/lock-site/`. A alteração do site precisa estar publicada antes de testar o aplicativo.
- Esta pasta contém o projeto-fonte Android Studio e um workflow GitHub Actions para gerar um APK de teste. Não inclui um APK pronto ou assinado para distribuição; a compilação precisa ocorrer no Android Studio ou no GitHub Actions.
- Captura de tela é uma permissão sensível do Android. A confirmação do sistema é exibida a cada nova sessão, conforme as regras da plataforma.

## Publicação do site

Copie o `index.html` da raiz deste pacote para a raiz do repositório GitHub Pages e publique normalmente. Não substitua a extensão de PC: ela continua separada e não precisa ser alterada para este caminho Android.

## Requisitos de build

- Android Studio com Android SDK 35 instalado.
- JDK 17 ou superior.
- Gradle/Android Gradle Plugin é sincronizado pelo Android Studio.
- `minSdk 26`; compatível com versões Android 8.0 ou posteriores. A captura MediaProjection segue o fluxo de permissão do próprio Android.

## Privacidade

A transmissão só começa depois de confirmar a janela de captura do Android. O quadro é processado localmente no aparelho e encaminhado pelo fluxo WebRTC/PeerJS existente da sala. O serviço em primeiro plano exibe uma notificação enquanto captura a tela.
